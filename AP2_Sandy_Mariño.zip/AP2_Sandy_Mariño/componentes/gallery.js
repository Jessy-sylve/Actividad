// gallery.js
class GalleryComponent extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }
    connectedCallback() {
        this.shadowRoot.innerHTML = `
            <style>
                .gallery {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 1em;
                    padding: 2em;
                }
                .gallery img {
                    width: 200px;
                    height: 200px;
                    object-fit: cover;
                }
            </style>
            <div class="gallery" id="gallery-container"></div>
        `;
        this.fetchData();
    }
    fetchData() {
        fetch('https://pokeapi.co/api/v2/pokemon?limit=10')
            .then(response => response.json())
            .then(data => {
                const container = this.shadowRoot.getElementById('gallery-container');
                data.results.forEach(pokemon => {
                    fetch(pokemon.url)
                        .then(res => res.json())
                        .then(pokeData => {
                            const img = document.createElement('img');
                            img.src = pokeData.sprites.front_default;
                            img.alt = pokemon.name;
                            container.appendChild(img);
                        });
                });
            })
            .catch(error => console.error('Error:', error));
    }
}
customElements.define('gallery-component', GalleryComponent);