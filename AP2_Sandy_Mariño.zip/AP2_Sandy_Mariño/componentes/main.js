// main.js
class MainComponent extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }
    connectedCallback() {
        this.shadowRoot.innerHTML = `
            <style>
                main {
                    padding: 1em;
                }
            </style>
            <main>
                <slot></slot>
            </main>
        `;
    }
}
customElements.define('main-component', MainComponent);