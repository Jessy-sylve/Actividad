// footer.js
class FooterComponent extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }
    connectedCallback() {
        this.shadowRoot.innerHTML = `
            <style>
                footer {
                    background-color: #212121;
                    color: white;
                    padding: 1em;
                    text-align: center;
                }
            </style>
            <footer>
                <p>&copy; 2024 Proyecto Aplicación Web Dinámico. Derechos Reservados.</p>
            </footer>
        `;
    }
}
customElements.define('footer-component', FooterComponent);