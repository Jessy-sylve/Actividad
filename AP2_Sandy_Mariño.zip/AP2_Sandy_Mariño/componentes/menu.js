// menu.js
class MenuComponent extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }
    connectedCallback() {
        this.shadowRoot.innerHTML = `
            <style>
                nav {
                    background-color: #a8207d;
                    padding: 1em;
                }
                nav a {
                    color: white;
                    text-decoration: none;
                    padding: 0.5em;
                    margin-right: 1em;
                }
                nav a:hover {
                    background-color: #8761e3;
                }
            </style>
            <nav>
                <a href="#profile">Perfil</a>
                <a href="#table">Tabla</a>
                <a href="#gallery">Galería</a>
            </nav>
        `;
    }
}
customElements.define('menu-component', MenuComponent);