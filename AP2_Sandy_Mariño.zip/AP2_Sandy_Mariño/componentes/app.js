// app.js
document.addEventListener('DOMContentLoaded', () => {
    const menuLinks = document.querySelectorAll('nav a');
    const pages = document.querySelectorAll('main-component > *');

    menuLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('href').substring(1);
            pages.forEach(page => {
                page.style.display = 'none';
            });
            document.getElementById(target).style.display = 'block';
        });
    });

    // Mostrar la primera página por defecto
    pages[0].style.display = 'block';
});