// social-profile.js
class SocialProfileComponent extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }
    connectedCallback() {
        this.shadowRoot.innerHTML = `
            <style>
                .profile {
                    background-color: #e0e0e0;
                    padding: 1em;
                }
                img {
                    width: 100px;
                    height: 100px;
                    border-radius: 50%;
                    margin-bottom: 1em;
                }
            </style>
            <div class="profile">
                <img src="datos/foto_perfil.png" alt="Foto de Perfil">
                <h2>Amante Pokemon</h2>
                <p>En el área de desarrollo y codifición, en ésta oportunidad, estamos explorando uno de mis más grandes intereses, los avatares Pokemon</p>
            </div>
        `;
    }
}
customElements.define('social-profile-component', SocialProfileComponent);