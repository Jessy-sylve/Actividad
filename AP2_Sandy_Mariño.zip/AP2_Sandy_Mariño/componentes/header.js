// header.js
class HeaderComponent extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }
    connectedCallback() {
        this.shadowRoot.innerHTML = `
            <style>
                header {
                    background-color: #ff55f5;
                    color: white;
                    padding: 1em;
                    text-align: center;
                }
            </style>
            <header>
                <h1>Proyecto JS, API con Carga Dinámica</h1>
            </header>
        `;
    }
}
customElements.define('header-component', HeaderComponent);