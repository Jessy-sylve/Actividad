# Aplicación Web con Componentes Personalizados

## Descripción

Esta aplicación web utiliza componentes personalizados (Custom Elements) con Shadow DOM para crear una estructura modular. Los componentes incluyen Header, Footer, Main, Menu, SocialProfile, CustomTable y Gallery.

## Componentes

- **Header Componente:** Muestra un encabezado con un título.
- **Footer Componente:** Muestra un pie de página con información de copyright.
- **Main Componente:** Contenedor principal que utiliza slots para contenido dinámico.
- **Menu Componente:** Menú de navegación con enlaces a las diferentes páginas.
- **SocialProfile Componente:** Página de perfil de usuario con datos estáticos.
- **CustomTable Componente:** Tabla personalizada que carga datos desde una API REST.
- **Gallery Componente:** Página de galería con imágenes obtenidas desde una API REST.

## Uso

- Abre `index.html` en un navegador web.
- Utiliza el menú de navegación para cambiar entre las páginas.

## Tecnologías Utilizadas

- HTML5
- CSS3
- JavaScript (Custom Elements, Shadow DOM, Fetch API)

